/**
  * Provides the classes necessary to handle GDAL rasters.
  *
  * This package provides the classes for the Dataset, Band, Driver,... objects that are used for handling GDAL rasters.
  */
package org.gdal.gdal;